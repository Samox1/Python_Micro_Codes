# Plik proszę nazwać numerem swojego indeksu.
# Plik powinien zawierać tylko definicję funkcji z Zadania 1-4.
# 
# Zadanie 1:
# a) Stwórz w C++ własną implementację funkcji "matrix" przekształcającą dowolny wektor na macierz o wymiarach "n x k".
# b) Funkcja przyjmuje następujące parametry: wektor, liczba wierszy, liczba kolumn, wskazanie czy dane wstawine są wierszami czy kolumnami, nazwy wymiarów.
# c) Funkcja powinna zwracać macierz.
# d) Funkcja będzie testowana na wektorach numerycznych i tekstowych.
# e) Nazwa funkcji to "matrixCpp".
# 
# Zadanie 2:
# a) Stwórz w C++ własną implementację funkcji "cumsum" zwracającą sumy skumulowane.
# b) Funkcja przyjmuje następujące parametry: wektor.
# c) Funkcja powinna zwracać wektor.
# d) Funkcja będzie testowana na wektorach numerycznych i tekstowych.
# e) Nazwa funkcji to "cumsumCpp".
# 
# Zadanie 3:
# a) Stwórz w C++ własną implementację funkcji "rev" zwracającą wektor z elementami o odwróconej kolejności.
# b) Funkcja przyjmuje następujące parametry: wektor.
# c) Funkcja powinna zwracać wektor.
# d) Funkcja będzie testowana na wektorach numerycznych i tekstowych.
# e) Nazwa funkcji to "revCpp".
# 
# Zadanie 4:
# a) Stwórz w R własną implementację oparatora "%*%" mnożącego dwie macierze.
# b) Funkcja przyjmuje następujące parametry: macierz1, macierz2.
# c) Funkcja powinna zwracać macierz, a jeżeli pomnożenie macierzy nie jest możliwe to komunikat "Opracja niemożliwa".
# d) Funkcja będzie testowana na macierzach o różnych wymiarach.
# e) Nazwa funkcji to "matmultR".
# 
# Zadanie 5:
# a) Dokonaj przetestowania wydajności opracowanych powyżej funkcji na losowo stworzonych wektorach.
# b) Porównaj wydajność własnych funkcji z funkcjami wbudowanymi.
# c) Dokonaj profilowania opracowanych funkcji w celu znalezienia ew. wąskich gardeł.
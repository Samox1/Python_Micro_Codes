import os
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

def read_file(file,height, width):
    img = plt.imread(file)
    img = Image.fromarray(img)
    img = np.array(img.resize((height, width), Image.BICUBIC))
    return img

file1 = 'obraz1.jpg'
file2 = 'obraz2.jpg'
height = 100
width = 100
img1 = read_file(file1,height = height, width = width)
img2 = read_file(file2,height = height, width = width)

for alpha in np.linspace(0,1,10):
    img = (alpha * img1.astype(float) + (1-alpha)*img2.astype(float)).astype(np.uint8)
    plt.imshow(img)
    plt.show()
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt


x = np.linspace(-7.5,7.5,100)
y_softplus = tf.nn.softplus(x).numpy()
y_relu = tf.nn.relu(x).numpy()


plt.plot(x,y_softplus, label = 'softplus')
plt.plot(x,y_relu, label = 'relu')
plt.legend(loc = 'best')
plt.show()

import tensorflow as tf
from tensorflow.keras import losses
from read_data import read_data
from sklearn.model_selection import RepeatedKFold
from Random_Network import Random_Network
import numpy as np
from One_Network import One_Network
import pandas as pd
from sklearn.metrics import roc_auc_score

import os
def mk_directory(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
    return directory

tf.random.set_seed(1234)
np.random.seed(1234)

data_path = 'D:/kas/dane_brodawki'
# results_path = 'D:/DataMining/STO/Random_Network/wyniki_07_02_2021_v2'
results_path = 'Wyniki/'

# data_path = '/home/bartpaw/dane_od_Moniki'
# results_path = '/home/bartpaw/wyniki_101'

k_iteration = 101

X_all, y_all = read_data(directory=data_path, height=28, width=28)

nr = np.arange(X_all.shape[0])
np.random.shuffle(nr)
X_all, y_all = X_all[nr], y_all[nr]


X_all = (X_all - 127.5) / 127.5  # Normalize the images to [-1, 1]
n_splits=10
n_repeats=10
rkf = RepeatedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=2652124)
it_repeat = 1
it_fold = 0

factivation1 = tf.keras.activations.relu
factivation2 = tf.keras.activations.softplus


dir_to_save = mk_directory(results_path)

batch_size = 16
for train_index, test_index in rkf.split(X_all):
    it_fold +=1
    dir_to_save_rf = dir_to_save + f"/repeat{it_repeat}_fold{it_fold}/"
    if not os.path.isdir(dir_to_save_rf):
        dir_to_save_rf = mk_directory(directory=dir_to_save_rf)
        X_train, y_train, X_test, y_test = X_all[train_index], y_all[train_index], X_all[test_index], y_all[test_index]

        random_network = Random_Network(factivation1=factivation1, factivation2=factivation2, k=k_iteration)
        one_network1 = One_Network(factivation1=factivation1)
        one_network2 = One_Network(factivation1=factivation2)

        def loss(model, X, y):
            cce = losses.CategoricalCrossentropy(from_logits=True)
            return cce(y_true=y, y_pred=model(X))

        def train(loss, model, opt, X, y):
            with tf.GradientTape() as tape:
                gradients = tape.gradient(loss(model, X, y), model.trainable_variables)
                gradient_variables = zip(gradients, model.trainable_variables)
                opt.apply_gradients(gradient_variables)

        opt_one1 = tf.optimizers.Adam(learning_rate=0.001)
        opt_one2 = tf.optimizers.Adam(learning_rate=0.001)
        opt_random = tf.optimizers.Adam(learning_rate=0.001)

        train_batch_size = 16
        train_no_of_batches = np.round(np.linspace(0, X_train.shape[0], int(np.round(X_train.shape[0] / train_batch_size,0)) + 1),0).astype(np.int)
        nr = np.arange(X_train.shape[0])

        ACC_one1, ACC_one2, ACC_random = [], [], []
        AUC_one1, AUC_one2, AUC_random = [], [], []

        for epoch in range(1000):
            dir_to_save_epoch = mk_directory(dir_to_save_rf + f"epoch{epoch}/")
            np.random.shuffle(nr)

            for batch in range(len(train_no_of_batches) - 1):
                pocz = train_no_of_batches[batch]
                kon = train_no_of_batches[batch + 1]

                train(loss, one_network1, opt_one1, X_train[nr[pocz:kon]], y_train[nr[pocz:kon]])
                train(loss, one_network2, opt_one2, X_train[nr[pocz:kon]], y_train[nr[pocz:kon]])
                train(loss, random_network, opt_random, X_train[nr[pocz:kon]], y_train[nr[pocz:kon]])


            y_test_est_continous_one1 = one_network1.predict(np.concatenate((X_train,X_test)))
            y_test_est_continous_one2 = one_network2.predict(np.concatenate((X_train,X_test)))
            y_test_est_continous_random = random_network.predict(np.concatenate((X_train,X_test)))

            y_train_est_continous_one1 = y_test_est_continous_one1[:X_train.shape[0]]
            y_test_est_continous_one1 = y_test_est_continous_one1[-X_test.shape[0]:]

            y_train_est_continous_one2 = y_test_est_continous_one2[:X_train.shape[0]]
            y_test_est_continous_one2 = y_test_est_continous_one2[-X_test.shape[0]:]

            y_train_est_continous_random = y_test_est_continous_random[:X_train.shape[0]]
            y_test_est_continous_random = y_test_est_continous_random[-X_test.shape[0]:]

            y_test_est_discrete_one1 = np.argmax(y_test_est_continous_one1, axis=1)
            y_test_est_discrete_one2 = np.argmax(y_test_est_continous_one2, axis=1)
            y_test_est_discrete_random = np.argmax(y_test_est_continous_random, axis=1)

            df_train_one1 = pd.DataFrame(data=np.concatenate((y_train_est_continous_one1, y_train), axis=1),
                                        columns=['y_pred0', 'y_pred1', 'y_true0', 'y_true1'])
            df_train_one2 = pd.DataFrame(data=np.concatenate((y_train_est_continous_one2, y_train), axis=1),
                                        columns=['y_pred0', 'y_pred1', 'y_true0', 'y_true1'])
            df_train_random = pd.DataFrame(data=np.concatenate((y_train_est_continous_random, y_train), axis=1),
                                          columns=['y_pred0', 'y_pred1', 'y_true0', 'y_true1'])
            df_test_one1 = pd.DataFrame(data=np.concatenate((y_test_est_continous_one1, y_test), axis = 1),
                                   columns = ['y_pred0', 'y_pred1','y_true0','y_true1'])
            df_test_one2 = pd.DataFrame(data=np.concatenate((y_test_est_continous_one2, y_test), axis = 1),
                                   columns = ['y_pred0', 'y_pred1','y_true0','y_true1'])
            df_test_random = pd.DataFrame(data=np.concatenate((y_test_est_continous_random, y_test), axis = 1),
                                   columns = ['y_pred0', 'y_pred1','y_true0','y_true1'])


            df_train_one1.to_csv(dir_to_save_epoch + f"df_train_one1_fold{it_fold}_repeat{it_repeat}.csv", index=False)
            df_train_one2.to_csv(dir_to_save_epoch + f"df_train_one2_fold{it_fold}_repeat{it_repeat}.csv", index=False)
            df_train_random.to_csv(dir_to_save_epoch + f"df_train_random_fold{it_fold}_repeat{it_repeat}.csv", index=False)

            df_test_one1.to_csv(dir_to_save_epoch + f"df_test_one1_fold{it_fold}_repeat{it_repeat}.csv", index=False)
            df_test_one2.to_csv(dir_to_save_epoch + f"df_test_one2_fold{it_fold}_repeat{it_repeat}.csv", index=False)
            df_test_random.to_csv(dir_to_save_epoch + f"df_test_random_fold{it_fold}_repeat{it_repeat}.csv", index=False)


            ACC_one1_ = np.mean(y_test_est_discrete_one1==y_test[:,1])
            ACC_one2_ = np.mean(y_test_est_discrete_one2 == y_test[:, 1])
            ACC_random_ = np.mean(y_test_est_discrete_random == y_test[:, 1])
            ACC_one1.append(ACC_one1_)
            ACC_one2.append(ACC_one2_)
            ACC_random.append(ACC_random_)

            AUC_one1_ = roc_auc_score(y_true=y_test[:,1], y_score=y_test_est_continous_one1[:,1])
            AUC_one2_ = roc_auc_score(y_true=y_test[:, 1], y_score=y_test_est_continous_one2[:, 1])
            AUC_random_ = roc_auc_score(y_true=y_test[:, 1], y_score=y_test_est_continous_random[:, 1])
            AUC_one1.append(AUC_one1_)
            AUC_one2.append(AUC_one2_)
            AUC_random.append(AUC_random_)

            np.save(dir_to_save_rf + '/AUC_one1', np.array(AUC_one1))
            np.save(dir_to_save_rf + '/AUC_one2', np.array(AUC_one2))
            np.save(dir_to_save_rf + '/AUC_random', np.array(AUC_random))

            np.save(dir_to_save_rf + '/ACC_one1', np.array(ACC_one1))
            np.save(dir_to_save_rf + '/ACC_one2', np.array(ACC_one2))
            np.save(dir_to_save_rf + '/ACC_random', np.array(ACC_random))

            print(f"repeat {it_repeat}, fold = {it_fold}, epoch = {epoch}:")
            print(f"ACC_one1_ = {ACC_one1_}, mean ACC_one1 = {np.mean(np.array(ACC_one1))}")
            print(f"ACC_one2_ = {ACC_one2_}, mean ACC_one2 = {np.mean(np.array(ACC_one2))}")
            print(f"ACC_random_ = {ACC_random_}, mean ACC_random = {np.mean(np.array(ACC_random))}")
            print(f"AUC_one1_ = {AUC_one1_}, mean AUC_one1 = {np.mean(np.array(AUC_one1))}")
            print(f"AUC_one2_ = {AUC_one2_}, mean AUC_one2 = {np.mean(np.array(AUC_one2))}")
            print(f"AUC_random_ = {AUC_random_}, mean AUC_random = {np.mean(np.array(AUC_random))}")
            print('')
    else:
        print(f"directory {dir_to_save_rf} already exists")

    if it_fold==n_splits:
        it_fold = 0
        it_repeat += 1


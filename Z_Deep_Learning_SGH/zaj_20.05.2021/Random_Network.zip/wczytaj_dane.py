from listuj_sciezke import listuj_sciezke
import os
import numpy as np
import matplotlib.pyplot as plt
import cv2
# from scipy.misc import imresize
# from scipy import interpolate

def wczytaj_dane(katalog,wys,szer):
    katalogi, _ = listuj_sciezke(katalog)
    X_data = []
    Y_label=[]
    for i,_ in enumerate(katalogi):
        print(katalog+'/'+katalogi[i])
        _, pliki = listuj_sciezke(katalog+'/'+katalogi[i])
        for j,_ in enumerate(pliki):
            plik=os.path.join(katalog+'/'+katalogi[i], pliki[j])
            img = cv2.imread(plik)
            img = cv2.resize(img, (szer, wys),cv2.INTER_LINEAR)
            X_data.append(img)
            Y_label.append(katalogi[i])

    Y_label = np.array(Y_label)
    unikalne_klasy = np.unique(Y_label)
    liczba_klas = len(unikalne_klasy)
    Y_label= np.array([Y_label == unikalne_klasy[i] for i in range(liczba_klas)]).astype(np.int).T

    return (np.array(X_data,dtype=np.float32), np.array(Y_label).astype(np.float32))




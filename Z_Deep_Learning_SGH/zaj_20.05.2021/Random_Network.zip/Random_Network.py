import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras import layers, losses
import numpy as np
from utils import softmax


class Random_Network(Model):
    def __init__(self, factivation1, factivation2, k=1001, **kwargs):
        super().__init__(**kwargs)
        self.k = k
        self.conv1a = layers.Conv2D(32, (3, 3), activation=factivation1, padding='same')
        self.conv1b = layers.Conv2D(32, (3, 3), activation=factivation2, padding='same')
        self.pool1 = layers.MaxPool2D(pool_size=(3, 3), strides=2, padding='valid')

        self.conv2a = layers.Conv2D(32, (3, 3), activation=factivation1, padding='same')
        self.conv2b = layers.Conv2D(32, (3, 3), activation=factivation2, padding='same')
        self.pool2 = layers.MaxPool2D(pool_size=(3, 3), strides=2, padding='valid')

        self.conv3a = layers.Conv2D(64, (3, 3), activation=factivation1, padding='same')
        self.conv3b = layers.Conv2D(64, (3, 3), activation=factivation2, padding='same')
        self.pool3 = layers.MaxPool2D(pool_size=(3, 3), strides=2, padding='valid')

        self.flat = layers.Flatten()

        self.dense1a = layers.Dense(units=64, activation=factivation1)
        self.dense1b = layers.Dense(units=64, activation=factivation2)

        self.dense2a = layers.Dense(units=2, activation=factivation1)
        self.dense2b = layers.Dense(units=2, activation=factivation2)



    def random_number1(self, x):
        x = tf.random.uniform(shape=[x.shape[0], 1, 1, 1])
        return x

    def random_number2(self, x):
        x = tf.random.uniform(shape=[x.shape[0], 1])
        return x

    def call(self, x, alpha_dict = None):

        if alpha_dict is None:
            alpha1 = self.random_number1(x)
            alpha2 = self.random_number1(x)
            alpha3 = self.random_number1(x)
            alpha4 = self.random_number2(x)
            alpha5 = self.random_number2(x)
        else:
            alpha1 = alpha_dict['alpha1']
            alpha2 = alpha_dict['alpha2']
            alpha3 = alpha_dict['alpha3']
            alpha4 = alpha_dict['alpha4']
            alpha5 = alpha_dict['alpha5']

        x = alpha1 * self.conv1a(x) + (1.0-alpha1) * self.conv1b(x)
        x = self.pool1(x)

        x = alpha2 * self.conv2a(x) + (1.0 - alpha2) * self.conv2b(x)
        x = self.pool2(x)

        x = alpha3 * self.conv3a(x) + (1.0 - alpha3) * self.conv3b(x)
        x = self.pool3(x)

        x = self.flat(x)

        x = alpha4 * self.dense1a(x) + (1.0 - alpha4) * self.dense1b(x)

        x = alpha5 * self.dense2a(x) + (1.0 - alpha5) * self.dense2b(x)
        return x

    def predict(self, X):
        y_test_est_continous = softmax(
            self.call(X, {'alpha1': 0.5, 'alpha2': 0.5, 'alpha3': 0.5, 'alpha4': 0.5, 'alpha5': 0.5}).numpy())
        for trial in range(self.k - 1):
            alpha_dict = {'alpha1': np.random.rand(),
                          'alpha2': np.random.rand(),
                          'alpha3': np.random.rand(),
                          'alpha4': np.random.rand(),
                          'alpha5': np.random.rand()}
            y_test_est_continous += softmax(self.call(X, alpha_dict).numpy())
        y_test_est_continous = y_test_est_continous / (self.k)
        return y_test_est_continous


